"""Independent checks of the retrieved evening snapshot. No source edits."""
from pathlib import Path
import sys, json, itertools, tempfile, os, hashlib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'source'))
import storage_model as sm
import benchmarks as b
import two_factor_probe as p

rows = []
def record(check, **result):
    item = dict(check=check, **result)
    rows.append(item)
    print(json.dumps(item, default=str), flush=True)

# Exhaustive schedules, independent of the production dynamic recursion.
rng = np.random.default_rng(10871)
feasible = infeasible = 0
max_error = 0.0
for case in range(48):
    days, cap = 4, 4
    prices = rng.uniform(10, 60, days)
    start, terminal = map(int, rng.integers(0, cap + 1, 2))
    floors = rng.integers(0, cap + 1, days)
    ceilings = np.array([rng.integers(f, cap + 1) for f in floors])
    # Half the cases have a wide feasible corridor.
    if case % 2 == 0:
        floors[:] = 0
        ceilings[:] = cap
    inj = rng.integers(1, 3, days)
    wdr = rng.integers(1, 3, days)
    ir = np.linspace(1, .5, cap + 1)
    wr = np.linspace(.5, 1, cap + 1)
    fuel = .015 if case % 3 else 0.0
    fee = .7
    best = -np.inf
    for moves in itertools.product(range(-2, 3), repeat=days):
        inv, cash, valid = start, 0.0, True
        for t, move in enumerate(moves):
            if not floors[t] <= inv <= ceilings[t]:
                valid = False; break
            low = -min(inv, int(wdr[t] * wr[inv]))
            high = min(cap - inv, int(inj[t] * ir[inv]))
            if not low <= move <= high:
                valid = False; break
            cash += np.exp(-.08 * t / 365.25) * (
                -move * prices[t] * (1/(1-fuel) if move > 0 else 1)
                - abs(move) * fee)
            inv += move
        if valid and inv == terminal:
            best = max(best, cash)
    curve = pd.Series(prices, index=pd.date_range('2026-01-01', periods=days))
    s = sm.Storage('2026-01-01', '2026-01-01', '2026-01-04',
                   daily_curve=curve, n_p=0, v_step=1., sVol=.5, sMR=1.,
                   clips_per_day=2, discount_rate=.08, fuel_loss=fuel)
    s.set_volume_states(cap, initial_state=start)
    s.i_curve[:] = 0; s.w_curve[:] = 0
    s.i_curve[:days] = inj; s.w_curve[:days] = wdr
    s.i_ratch[:] = ir; s.w_ratch[:] = wr
    s.mintunnel[:days] = floors; s.max_tunnel[:days] = ceilings
    s.i_cost[:] = fee; s.w_cost[:] = fee
    s.t_p_curve[:] = -1e9; s.t_p_curve[terminal] = 0
    try:
        s.build()
        actual = float(s.v[0, 0, start])
        assert np.isfinite(best), (case, best, actual)
        max_error = max(max_error, abs(actual-best))
        assert abs(actual-best) < 1e-9, (case, best, actual)
        feasible += 1
    except ValueError:
        assert not np.isfinite(best), (case, best)
        infeasible += 1
record('independent_exhaustive_bounds', cases=48, feasible=feasible,
       infeasible=infeasible, max_abs_error=max_error)

# Actual optimiser policies in the earlier adverse-price examples.
for level in (300., 1000., 10000.):
    s, date, floor = b.adverse_price_floor(level)
    s.build()
    law = s.prob[(date-s.valDate).days].sum(axis=0)
    record('adverse_price_hard_floor', price=level,
           breach_mass=float(law[:floor].sum()),
           value=float(s.v[0,s.n_p,s.initial_state]))

# Days-based input still changes contractual rates before ratchet diagnostics.
for days_in, days_out, grid in [(30,90,30),(30,90,90),(30,65,60),(30,65,390)]:
    prm = dict(product_type='storage', valDate='2026-06-01',
               storageStart='2027-01-01',storageEnd='2027-12-31',
               n_states=grid,capacity_mwh=600000.,inj_days=days_in,wdr_days=days_out,
               vol=.5,sMR=1.,n_p_full=0,run_intrinsic=True,
               inj_cost=0.,wdr_cost=0.,discount_rate=.1,daily_curve=b.monthly_curve())
    derived=sm.params_for_run_valuation(prm)
    s,r=sm.run_valuation(None,derived)
    record('base_rate_rounding',requested_in_days=days_in,requested_out_days=days_out,
           grid=grid,requested_wdr_mwh=600000/days_out,
           effective_wdr_mwh=float(s.w_curve.max()*s.v_step),
           effective_out_days=grid/derived['wdr_rate'],
           reported_ratchet_losses=sm.worst_ratchet_rate_loss(s),
           value=r['total_eur'])

# A separate explicit source can be replaced by the unrelated global cache.
with tempfile.TemporaryDirectory() as td:
    path=Path(td)/'different_quotes.xlsx'
    pd.DataFrame({'quote_date':[pd.Timestamp('2026-01-05')],
                  'TTFc1':[999.]}).to_excel(path,index=False)
    cached=Path(b._PARQUET_CACHE)
    if cached.exists():
        stamp=cached.stat().st_mtime-60
        os.utime(path,(stamp,stamp))
        loaded=b.load_quote_matrix(path)
        record('explicit_workbook_cache_substitution', expected_rows=1,
               expected_c1=999.,actual_rows=len(loaded),
               actual_first_c1=float(loaded['TTFc1'].iloc[0]),
               actual_last_date=str(loaded['quote_date'].max()))

# Compare analytic matching with the transition law the probe actually uses.
k, xi = 4., .1
nodes, P = p._ou_lattice(k, p.SIG_CHI)
q=np.zeros(len(nodes)); q[len(nodes)//2]=1
for _ in range(p.N_T-1): q=q@P
variance=float(q@nodes**2-(q@nodes)**2)
T=(p.N_T-1)*p.DT
unit=variance/p.SIG_CHI**2
claimed=p.matched_sig_chi(xi,'terminal',kappa=k)
correct=np.sqrt(p.SIG_CHI**2-xi**2*T/unit)
base=p.value_swing(k,0,strike=20.)
original=p.value_swing(k,xi,strike=20.,sig_chi=claimed)
matched=p.value_swing(k,xi,strike=20.,sig_chi=correct)
record('terminal_variance_anchor', last_decision_years=T, claimed_horizon=p.N_T*p.DT,
       base_variance=variance,comparison_variance=claimed**2*unit+xi**2*T,
       claimed_sigma_chi=claimed,matched_sigma_chi=correct,
       matched_variance=correct**2*unit+xi**2*T,
       base_swing=base,original_swing=original,matched_swing=matched,
       original_effect=original/base-1,matched_effect=matched/base-1)

# A correlation assumption determines the direction of variance allocation.
rho, xi = -.9, .3
chi=-rho*xi+np.sqrt(.6**2-(1-rho**2)*xi**2)
record('negative_correlation_variance_allocation', rho=rho,sigma_xi=xi,
       sigma_chi=chi,target_variance=.36,
       resulting_variance=chi**2+xi**2+2*rho*chi*xi,
       note='analytic counterexample, not a calibration')

# Under flat initial forwards, average the diffusion loading over the delivery
# month. With point maturity at month-end the averaged loading is larger.
k=1.; sigma=.5; h=1/12
point=sigma*(np.exp(-k*.5)-np.exp(-k*1.))
factor=np.expm1(k*h)/(k*h)
record('delivery_averaging_not_universal_upper_bound',
       point_month_end_ratio_vol=point,monthly_average_ratio_vol=point*factor,
       ratio=factor,note='equal 1/12-year delivery periods ending at .5 and 1 years, flat initial forwards')

# Numerical gate robustness; artificial input tables, not valuations.
for name,values,grids in [
    ('nan_results',[np.nan,np.nan,np.nan],[240,480,960]),
    ('duplicate_grid',[1e6,1e6,1e6],[240,240,240]),
    ('material_small_contract',[10000.,9500.,9000.],[240,480,960])]:
    tab=pd.DataFrame({'n_states':grids,'total_eur':values,'intrinsic_eur':values})
    passed,steps=b.convergence_verdict(tab)
    record('convergence_gate_input',case=name,passed=bool(passed),values=values,grids=grids)

(ROOT/'independent_results.json').write_text(json.dumps(rows,indent=2,default=str))
manifest={str(f.relative_to(ROOT/'source')):hashlib.sha256(f.read_bytes()).hexdigest()
          for f in (ROOT/'source').rglob('*') if f.is_file()
          and '__pycache__' not in str(f) and '.pytest_cache' not in str(f)}
(ROOT/'source_sha256.json').write_text(json.dumps(manifest,indent=2))

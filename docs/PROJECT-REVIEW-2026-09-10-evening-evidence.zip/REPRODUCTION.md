# Reproducing the evening project review

The reviewed canonical commit is `b66d0a4b9a99b3772258007401bceefa24142f33` in `dmitry-goryunov/Storage`.

The evidence archive does not include the user's repository or market workbook. Use a checkout of that commit as `source/` beside `check_current.py`. Use Python 3.12 and install the repository's `requirements-lock.txt` into a suitable environment outside any synchronised project folder. The review used NumPy 2.5.3, pandas 3.0.5, SciPy 1.18.1 and Numba 0.67.0, with two Numba threads and one OpenBLAS thread for the independent probes.

From this directory, run:

```bash
NUMBA_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 python check_current.py
```

From `source/`, run:

```bash
NUMBA_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 python -m pytest -q
NUMBA_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 python benchmarks.py
OPENBLAS_NUM_THREADS=1 python two_factor_probe.py
```

The explicit-workbook cache substitution check requires a default parquet cache to exist. In a clean checkout, calling `benchmarks.load_quote_matrix()` once creates it where writing is permitted. The review used the cache fetched with the Drive snapshot; `default_cache_verification.json` records a fresh-workbook comparison of its values.

`independent_results.json` contains the independent checks. JSON NaN values are intentional in the constructed convergence-gate counterexample; Python's JSON reader accepts them. The corresponding output can also be read in `independent_checks.log`.

The harsh-profile convergence table was generated with:

```python
import benchmarks as b
table = b.inventory_grid_ladder(
    ladder=(960, 1920, 3840), ratchets=b.HARSH_RATCHETS, n_p=0)
print(b.convergence_verdict(table))
```

`pytest.log` records the extracted-snapshot run: 115 passes and one failure because `git ls-files` is unavailable without repository metadata. This is not described as a model failure. `ci_verification.txt` records the canonical commit's independently fetched GitHub CI result: 116 passes. `snapshot_git_comparison.json` confirms 37 source/data/test/document matches to the canonical Git tree after text line-ending normalisation. `source_sha256.json` records the exact local file bytes used; Windows line endings can differ from a Linux Git checkout without changing source text.

The probe variance correction matches the existing discrete lattice at its actual last decision date. It is a diagnostic counterexample to the published matching claim, not a completed continuous-time valuation or market calibration.

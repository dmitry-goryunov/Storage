"""Independent review probes; source files are imported unchanged."""
from pathlib import Path
import sys, json, time, hashlib
import numpy as np
import pandas as pd

ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'source'))
import storage_model as sm
OUT=ROOT/'evidence'; OUT.mkdir(exist_ok=True)
records=[]
def record(name,**kw):
    row=dict(check=name,**kw);records.append(row);print(json.dumps(row,default=str),flush=True)

def short(**kw):
    curve=pd.Series(30.,index=pd.date_range('2026-01-01','2026-03-31'))
    curve.loc['2026-01-01']=20.
    p=dict(product_type='storage',valDate='2026-01-01',storageStart='2026-01-01',storageEnd='2026-01-03',capacity_mwh=100.,daily_max=100.,clips_per_day=10,inj_rate=10,wdr_rate=10,initial_inv_clips=0,terminal_inv_clips=0,inj_cost=0.,wdr_cost=0.,vol=.5,sMR=1.,n_p_full=0,run_intrinsic=False,discount_rate=0.,daily_curve=curve)
    p.update(kw);return sm.run_valuation(None,p)

# Opening-inventory reconstruction: a physically satisfied floor is rejected.
try:
    m,r=short(initial_inv_clips=10,min_inventory={'2026-01-02':1.})
    record('nonzero_initial_floor',status='accepted')
except ValueError as e:
    record('nonzero_initial_floor',status='rejected',error=str(e))
m,r=short(initial_inv_clips=10)
b=sm.apply_inventory_bounds(m,{'min_inventory':{'2026-01-02':1.}})
m.build()
actual=(m.prob[1].sum(axis=0)*np.arange(m.n_op)).sum()
record('nonzero_initial_floor_actual',opening_clips=actual,required=10)

# Rounding must be conservative, not nearest, for contractual inequalities.
for kind,fraction in [('min',.71),('max',.29)]:
    curve=pd.Series(30.,index=pd.date_range('2026-01-01','2026-03-31'))
    curve.loc['2026-01-01']=40. if kind=='min' else 20.
    m,r=short(daily_curve=curve,**{kind+'_inventory':{'2026-01-02':fraction}})
    inv=float(np.dot(m.prob[1].sum(axis=0),np.arange(m.n_op)))/10
    record('bound_rounding',kind=kind,requested=fraction,actual=inv,value=r['total_eur'])

# Distribution checker on a deliberately constructed inventory distribution.
m,_=short()
m.prob[:]=0.;m.strat[:]=0.
m.prob[0,m.n_p,0]=1.
m.strat[0,m.n_p,0]=6.
m.prob[1,m.n_p,0]=.4;m.prob[1,m.n_p,10]=.6
b=[(1,'min',pd.Timestamp('2026-01-02'),.5,5)]
try:
    sm.assert_inventory_bounds(m,b)
    record('pathwise_bound_checker_synthetic',status='accepted',expected_clips=6,required=5,breach_probability=.4,note='constructed checker input, not an optimiser-generated policy')
except ValueError as e:record('pathwise_bound_checker_synthetic',status='rejected',error=str(e))

# Cashflow identity and fuel must be distinguished from cash fees.
for loss in [0.,.015]:
    for fee in [0.,2.]:
        m,r=short(fuel_loss=loss,inj_cost=fee,wdr_cost=fee)
        n=m.n_t;action=m.strat*m.v_step;weighted=m.prob
        fees=np.sum(weighted*(np.maximum(action,0)*m.i_cost[:n,None,None]+np.maximum(-action,0)*m.w_cost[:n,None,None])*m.d_curve[:,None,None])
        gross=np.dot(np.asarray(m.delta[:n])*m.d_curve,m.fwd)
        record('fuel_and_fees',fuel_loss=loss,fee_per_leg=fee,value=r['total_eur'],gross_delta_reprice=gross,fees=fees,net_reprice=gross-fees,net_physical=sum(m.exp_ex),net_intrinsic_delta=sum(m.delta))

# Reproduce reference quantities and test volume grid convergence independently.
months={1:30.,2:30.,3:24.9,4:25.,5:25.,6:25.,7:25.,8:25.,9:25.,10:30.,11:30.,12:30.}
span=pd.date_range('2026-01-01','2029-06-30')
curve=pd.Series([months[t.month] for t in span],index=span)
def reference(nstates=60,kappa=1.,npfull=25,loss=0.,ratchets=None,**extra):
    p=dict(product_type='storage',valDate='2026-06-01',storageStart='2027-01-01',storageEnd='2027-12-31',capacity_mwh=600000.,daily_max=20000.,clips_per_day=nstates//30,inj_rate=nstates//30,wdr_rate=nstates//60,initial_inv_clips=0,terminal_inv_clips=0,inj_cost=0.,wdr_cost=0.,vol=.5,sMR=kappa,n_p_full=npfull,run_intrinsic=True,discount_rate=.10,daily_curve=curve,fuel_loss=loss)
    if ratchets is not None:p['ratchets']=ratchets
    p.update(extra)
    t=time.perf_counter();m,r=sm.run_valuation(None,p)
    out=dict(nstates=nstates,kappa=kappa,n_p=npfull,loss=loss,ratcheted=ratchets is not None,total=r['total_eur'],intrinsic=r['intrinsic_eur'],extrinsic_pct=100*r['extrinsic_eur']/r['total_eur'],seconds=time.perf_counter()-t)
    record('reference',**out)
    return m,r
for k in [.2,1.,4.]:reference(kappa=k)
for loss in [0.,.015]:reference(npfull=15,loss=loss)
profile=pd.DataFrame({'fullness':[0.,.5,.8,1.],'injection':[1.,1.,.6,.3],'withdrawal':[.3,.7,1.,1.]})
for ns in [240,480,960]:
    m,r=reference(nstates=ns,npfull=0,ratchets=profile)
    opening=np.einsum('tki,i->t',m.prob,np.arange(m.n_op))*m.v_step
    record('ratchet_grid',nstates=ns,max_inventory_fraction=opening.max()/600000,value=r['total_eur'])

# Monte Carlo reconciliation requires neither optimisation nor exact continuation.
rng=np.random.default_rng(7348)
F=np.array([25.,30.,28.]);sig=np.array([.4,.5,.3]);z=rng.normal(size=(100000,3))
S=F*np.exp(sig*z-.5*sig*sig)
Q=np.zeros_like(S);buy=S[:,0]<25.;Q[buy,0]=-1.;Q[buy,2]=1.
DF=np.exp(-.05*np.array([.2,.5,1.]))
value=np.mean(np.sum(DF*S*Q,axis=1));delta=np.mean(S*Q,axis=0)/F
record('mc_policy_identity',paths=len(S),value=value,delta_reprice=np.dot(DF*delta,F),absolute_error=abs(value-np.dot(DF*delta,F)),policy='buy one if S0<25, sell at final date; feasible non-optimal policy')

(OUT/'independent_checks.json').write_text(json.dumps(records,indent=2,default=str))
manifest={str(p.relative_to(ROOT/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'source').rglob('*') if p.is_file() and '__pycache__' not in str(p) and '.pytest_cache' not in str(p)}
(OUT/'source_sha256.json').write_text(json.dumps(manifest,indent=2))

from pathlib import Path
import json,sys,time
import numpy as np
import pandas as pd
from scipy.optimize import linprog
ROOT=Path(__file__).parent;sys.path.insert(0,str(ROOT/'source'))
import storage_model as sm
rows=[]
def rec(name,**kw):
    row=dict(check=name,**kw);rows.append(row);print(json.dumps(row,default=str),flush=True)
span=pd.date_range('2026-01-01','2029-06-30')
flatmonths={1:30.,2:30.,3:24.9,4:25.,5:25.,6:25.,7:25.,8:25.,9:25.,10:30.,11:30.,12:30.}
seasonal={1:31.,2:30.,3:28.,4:25.,5:22.,6:20.,7:19.,8:19.5,9:22.,10:25.5,11:28.5,12:30.5}
profile=pd.DataFrame({'fullness':[0.,.5,.8,1.],'injection':[1.,1.,.6,.3],'withdrawal':[.3,.7,1.,1.]})
for ns in [240,480,960,1920,3840]:
    curve=pd.Series([flatmonths[t.month] for t in span],index=span)
    p=dict(product_type='storage',valDate='2026-06-01',storageStart='2027-01-01',storageEnd='2027-12-31',capacity_mwh=600000.,daily_max=20000.,clips_per_day=ns//30,inj_rate=ns//30,wdr_rate=ns//60,initial_inv_clips=0,terminal_inv_clips=0,inj_cost=0.,wdr_cost=0.,vol=.5,sMR=1.,n_p_full=0,run_intrinsic=False,discount_rate=.1,daily_curve=curve,ratchets=profile)
    for bounded in [False,True]:
        q=p|({'min_inventory':{'2027-10-01':.7}} if bounded else {})
        try:
            t=time.perf_counter();m,r=sm.run_valuation(None,q)
            inv=np.einsum('tki,i->t',m.prob,np.arange(m.n_op))*m.v_step
            idx=(pd.Timestamp('2027-10-01')-m.valDate).days
            rec('ratchet_bound_grid',nstates=ns,bounded=bounded,value=r['total_eur'],peak=inv.max()/600000,oct1=inv[idx]/600000,seconds=time.perf_counter()-t)
        except ValueError as e:rec('ratchet_bound_grid',nstates=ns,bounded=bounded,error=str(e))

# Reproduce the alternative seasonal reference, and the design's purported 4.2%.
for k in [.2,1.,4.]:
    p.update(daily_curve=pd.Series([seasonal[t.month] for t in span],index=span),ratchets=None,capacity_mwh=600000.,clips_per_day=2,inj_rate=2,wdr_rate=1,n_p_full=25,sMR=k,run_intrinsic=True)
    m,r=sm.run_valuation(None,p)
    rec('seasonal_reference',kappa=k,total=r['total_eur'],intrinsic=r['intrinsic_eur'],extrinsic_pct=100*r['extrinsic_eur']/r['total_eur'])

# Direct stochastic optimiser example: expected floor passes despite path breaches.
# Only two withdrawal days with a long interval make the penalty temptation visible.
for level in [300.,1000.,3000.,10000.]:
    daily=pd.Series(level,index=pd.date_range('2026-01-01','2028-01-31'))
    daily.loc['2027-01-01']=1.
    m=sm.Storage('2026-01-01','2027-01-01','2027-12-31',daily_curve=daily,n_p=30,v_step=1,sVol=.8,sMR=1.)
    m.set_volume_states(10,initial_state=0)
    m.i_curve[:]=0.;m.w_curve[:]=0.
    m.i_curve[(pd.Timestamp('2027-01-01')-m.valDate).days]=10
    m.w_curve[(pd.Timestamp('2027-06-01')-m.valDate).days]=10
    m.w_curve[(pd.Timestamp('2027-12-01')-m.valDate).days]=10
    bounddate=pd.Timestamp('2027-06-02');idx=(bounddate-m.valDate).days
    bounds=sm.apply_inventory_bounds(m,{'min_inventory':{str(bounddate.date()):.2}})
    m.build();dist=m.prob[idx].sum(axis=0)
    try:sm.assert_inventory_bounds(m,bounds);status='accepted'
    except ValueError:status='rejected'
    rec('stochastic_bound',forward_level=level,status=status,expected_clips=np.dot(dist,np.arange(11)),required_clips=2,breach_probability=dist[:2].sum(),distribution=dist.tolist())

# Analytic one-factor instantaneous ratio volatility and mean-reversion sensitivity.
for k in [.2,1.,4.]:
    for t1,t2 in [(.5,1.),(1.,1.5)]:
        rec('analytic_ratio_vol',kappa=k,tau1=t1,tau2=t2,annualised_vol=.5*abs(np.exp(-k*t1)-np.exp(-k*t2)),stationary_sd=.5*abs(np.exp(-k*t1)-np.exp(-k*t2))/np.sqrt(2*k))
(ROOT/'evidence'/'followup_checks.json').write_text(json.dumps(rows,indent=2,default=str))

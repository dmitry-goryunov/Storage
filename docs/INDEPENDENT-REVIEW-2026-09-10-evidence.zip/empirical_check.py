from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.optimize import least_squares

ROOT = Path(__file__).parent
OUT = ROOT / 'evidence'
OUT.mkdir(exist_ok=True)
d = pd.read_excel(ROOT / 'source' / 'ttf q.xlsx').rename(columns={'Unnamed: 0':'date'})
d['date'] = pd.to_datetime(d['date'])
d = d.dropna(subset=['date']).set_index('date').sort_index()
cols = ['TTFc'+str(i) for i in range(1,56)]
d[cols+['DA']] = d[cols+['DA']].apply(pd.to_numeric,errors='coerce')
log = np.log(d[cols].where(d[cols] > 0))
returns = log.diff()
same_month = d.index.to_period('M').to_series(index=d.index).eq(d.index.to_period('M').to_series(index=d.index).shift())
pairs = [(1,3),(1,6),(6,12),(1,12),(12,24),(1,24)]
rows=[]
for label,mask in [('raw_2015',d.index >= '2015-01-01'),('no_roll_2015',(d.index >= '2015-01-01') & same_month),('no_roll_2015_2020',(d.index >= '2015-01-01') & (d.index < '2021-01-01') & same_month),('no_roll_2021_2023',(d.index >= '2021-01-01') & (d.index < '2024-01-01') & same_month),('no_roll_2024_on',(d.index >= '2024-01-01') & same_month)]:
    for i,j in pairs:
        z=returns.loc[mask,['TTFc'+str(i),'TTFc'+str(j)]].dropna()
        rows.append(dict(sample=label,pair=f'c{i}/c{j}',n=len(z),correlation=z.iloc[:,0].corr(z.iloc[:,1]),log_ratio_vol_252=(z.iloc[:,0]-z.iloc[:,1]).std()*np.sqrt(252),vol1=z.iloc[:,0].std()*np.sqrt(252),vol2=z.iloc[:,1].std()*np.sqrt(252)))
pd.DataFrame(rows).to_csv(OUT/'empirical_pairs.csv',index=False)
print(pd.DataFrame(rows).to_string(index=False),flush=True)

fitrows=[]
predictions=[]
for label,start,end in [('2015_on','2015-01-01','2030-01-01'),('2015_2020','2015-01-01','2021-01-01'),('2021_2023','2021-01-01','2024-01-01'),('2024_on','2024-01-01','2030-01-01')]:
    z=returns.loc[(d.index>=start)&(d.index<end)&same_month,cols[:24]].dropna()
    C=z.cov().to_numpy()*252
    sd=np.sqrt(np.diag(C)); w=np.outer(sd,sd)
    tau=np.arange(1,25)/12
    def mat(p,two):
        k,s=p[:2]; a=np.exp(-k*tau)
        if not two:return s*s*np.outer(a,a)
        sx,r=p[2:];return s*s*np.outer(a,a)+sx*sx+r*s*sx*(a[:,None]+a[None,:])
    for two in [False,True]:
        bounds=([.001,.001,.001,-.999],[30,5,5,.999]) if two else ([.001,.001],[30,5])
        starts=[[k,.5,.4,r] for k in [.3,1,3,8] for r in [-.5,.3]] if two else [[k,.5] for k in [.3,1,3,8]]
        fits=[least_squares(lambda p:((mat(p,two)-C)/w).ravel(),x,bounds=bounds,max_nfev=1500) for x in starts]
        best=min(fits,key=lambda x:np.sum(x.fun*x.fun)); M=mat(best.x,two)
        corr=M/np.sqrt(np.outer(np.diag(M),np.diag(M)))
        eig=np.linalg.eigvalsh(C)[::-1]
        row=dict(sample=label,model='SS2' if two else 'OU1',n=len(z),kappa=best.x[0],sigma_chi=best.x[1],sigma_xi=best.x[2] if two else 0,rho=best.x[3] if two else 0,normalised_rmse=np.sqrt(np.mean(best.fun**2)),c6_c12_corr=corr[5,11],c6_c12_ratio_vol=np.sqrt(max(M[5,5]+M[11,11]-2*M[5,11],0)),pca1=eig[0]/eig.sum(),pca2=(eig[0]+eig[1])/eig.sum(),pca3=eig[:3].sum()/eig.sum())
        fitrows.append(row)
        if label=='2015_on':
            for i,j in pairs:predictions.append(dict(model=row['model'],pair=f'c{i}/c{j}',correlation=corr[i-1,j-1],log_ratio_vol=np.sqrt(max(M[i-1,i-1]+M[j-1,j-1]-2*M[i-1,j-1],0))))
pd.DataFrame(fitrows).to_csv(OUT/'exploratory_covariance_fits.csv',index=False)
pd.DataFrame(predictions).to_csv(OUT/'fit_pairs.csv',index=False)
print('\nEXPLORATORY COVARIANCE FIT (mid-month maturity approximation, not pricing calibration)\n'+pd.DataFrame(fitrows).to_string(index=False),flush=True)

da=d['DA'].dropna()
metadata=dict(rows=len(d),columns=len(cols),start=str(d.index.min().date()),end=str(d.index.max().date()),duplicate_dates=int(d.index.duplicated().sum()),da_n=len(da),da_start=str(da.index.min().date()),da_end=str(da.index.max().date()),da_max_gap_days=int(da.index.to_series().diff().dt.days.max()),da_nonpositive=int((da<=0).sum()),missing_by_forward=d[cols].isna().sum().to_dict(),raw_2015_n=int((d.index>='2015-01-01').sum()),monthly_roll_rows=int(((d.index>='2015-01-01')&~same_month).sum()))
(OUT/'data_metadata.json').write_text(json.dumps(metadata,indent=2))
print('\nMETADATA\n'+json.dumps(metadata,indent=2),flush=True)

from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).parent;sys.path.insert(0,str(ROOT/'source'))
import storage_model as sm
rows=[]
def rec(name,**kw):
    row=dict(check=name,**kw);rows.append(row);print(json.dumps(row,default=str),flush=True)
span=pd.date_range('2026-01-01','2029-06-30')
curve=pd.Series(25.+6*np.cos(2*np.pi*(span.dayofyear.values-15)/365.25),index=span)
for k in [.2,1.,4.]:
    p=dict(product_type='storage',valDate='2026-06-01',storageStart='2027-01-01',storageEnd='2027-12-31',capacity_mwh=650000.,daily_max=650000/30,clips_per_day=13,inj_rate=13,wdr_rate=6,initial_inv_clips=0,terminal_inv_clips=0,inj_cost=0.,wdr_cost=0.,vol=.5,sMR=k,n_p_full=25,run_intrinsic=True,discount_rate=0.,daily_curve=curve)
    m,r=sm.run_valuation(None,p)
    rec('smooth_30_65_reference',kappa=k,value=r['total_eur'],intrinsic=r['intrinsic_eur'],extrinsic_pct=100*r['extrinsic_eur']/r['total_eur'])

# Current 30/60 notebook configuration, holding its constraints fixed.
months={1:30.,2:30.,3:24.9,4:25.,5:25.,6:25.,7:25.,8:25.,9:25.,10:30.,11:30.,12:30.}
curve=pd.Series([months[t.month] for t in span],index=span)
profile=pd.DataFrame({'fullness':[0.,.5,.8,1.],'injection':[1.,1.,.6,.3],'withdrawal':[.5,.8,1.,1.]})
params=dict(product_type='storage',valDate='2026-06-01',storageStart='2027-01-01',storageEnd='2027-12-31',capacity_mwh=600000.,daily_max=20000.,clips_per_day=8,inj_rate=8,wdr_rate=4,initial_inv_clips=0,terminal_inv_clips=0,inj_cost=0.,wdr_cost=0.,vol=.5,sMR=1.,n_p_full=25,run_intrinsic=True,discount_rate=.1,daily_curve=curve,ratchets=profile,min_inventory={'2027-10-01':.7})
def run(c):
    m,r=sm.run_valuation(None,params|{'daily_curve':c})
    n=m.n_t
    delta=pd.Series(m.delta[:n],index=m.date_span[:n]).loc['2027'].resample('MS').sum()
    dpv=pd.Series(m.delta_pv[:n],index=m.date_span[:n]).loc['2027'].resample('MS').sum()
    return delta,dpv,r['total_eur'],r
base,pv,v,r=run(curve)
rec('current_30_60',value=v,intrinsic=r['intrinsic_eur'],extrinsic_pct=100*r['extrinsic_eur']/v)
biggest=base.abs().max()
for month in range(1,13):
    results=[]
    for bump in [-.01,.01]:
        c=curve.copy();c.loc[c.index.month==month]*=1+bump
        de,_,vv,_=run(c);results.append((de.iloc[month-1],vv))
    swing=max(abs(z[0]-base.iloc[month-1]) for z in results)/biggest
    fd=(results[1][1]-results[0][1])/(.02*months[month])
    rec('monthly_hedge',month=month,delta=base.iloc[month-1],swing_fraction_of_largest=swing,pv_delta=pv.iloc[month-1],finite_difference_1pct=fd)

# Check within-day smoothing is not needed for the local derivative convention.
for month in [4,10]:
    eps=1e-5;cplus=curve.copy();cminus=curve.copy()
    mask=(curve.index.year==2027)&(curve.index.month==month)
    cplus.loc[mask]+=eps;cminus.loc[mask]-=eps
    _,_,vp,_=run(cplus);_,_,vm,_=run(cminus)
    fd=(vp-vm)/(2*eps)
    rec('local_derivative',month=month,finite_difference=fd,pv_delta=pv.iloc[month-1],relative_error=abs(fd-pv.iloc[month-1])/max(abs(fd),1))
(ROOT/'evidence'/'reference_and_hedges.json').write_text(json.dumps(rows,indent=2,default=str))

"""Small independent DP oracle: OU grid and an independent common level martingale.

This is a design counterexample, not a production Schwartz-Smith lattice.
Both solvers have identical physical action sets and hard terminal inventory.
"""
from pathlib import Path
import json
import numpy as np
from scipy.stats import norm
from scipy.optimize import brentq
ROOT=Path(__file__).parent

def solve(kappa=.8,sigma_xi=.0,fuel=.0,fee=.0,rate=.05,two=True):
    N=24;dt=1/24;sig=.5;cap=3
    x=np.linspace(-1.5,1.5,81);start=len(x)//2
    edges=np.r_[-np.inf,(x[:-1]+x[1:])/2,np.inf]
    mean=x*np.exp(-kappa*dt)
    std=sig*np.sqrt(-np.expm1(-2*kappa*dt)/(2*kappa))
    P=np.diff(norm.cdf((edges[None,:]-mean[:,None])/std),axis=1)
    prob=np.eye(1,len(x),start)[0]
    short_prices=[]
    for t in range(N):
        forward=25+5*np.cos(2*np.pi*t/N)
        short_prices.append(forward*np.exp(x)/np.dot(prob,np.exp(x)))
        prob=prob@P
    if not two:
        V=np.full((len(x),cap+1),-np.inf);V[:,0]=0
        for t in reversed(range(N)):
            # Safe propagation: terminal disallowed inventory stays -infinity.
            C=np.empty_like(V)
            for i in range(cap+1):C[:,i]=P@V[:,i] if np.isfinite(V[:,i]).all() else -np.inf
            new=np.full_like(V,-np.inf);S=short_prices[t];df=np.exp(-rate*t*dt)
            for i in range(cap+1):
                new[:,i]=C[:,i]
                if i>0:new[:,i]=np.maximum(new[:,i],C[:,i-1]+df*(S-fee))
                if i<cap:new[:,i]=np.maximum(new[:,i],C[:,i+1]-df*(S/(1-fuel)+fee))
            V=new
        return float(V[start,0])
    V=np.full((len(x),N+1,cap+1),-np.inf);V[:,:,0]=0
    a=sigma_xi*np.sqrt(dt)
    for t in reversed(range(N)):
        j=np.arange(t+1)
        M=np.exp(a*(2*j-t)-t*np.log(np.cosh(a)))
        S=short_prices[t][:,None]*M[None,:]
        C=np.full((len(x),t+1,cap+1),-np.inf)
        for i in range(cap+1):
            if np.isfinite(V[:,:,i]).all():C[:,:,i]=P@(.5*(V[:,:-1,i]+V[:,1:,i]))
        new=C.copy();df=np.exp(-rate*t*dt)
        for i in range(cap+1):
            if i>0:new[:,:,i]=np.maximum(new[:,:,i],C[:,:,i-1]+df*(S-fee))
            if i<cap:new[:,:,i]=np.maximum(new[:,:,i],C[:,:,i+1]-df*(S/(1-fuel)+fee))
        V=new
    return float(V[start,0,0])

rows=[]
for fuel,fee in [(0.,0.),(.015,0.),(0.,1.)]:
    for k in [.2,1.,4.]:
        base=solve(kappa=k,fuel=fuel,fee=fee,two=False)
        for sx in [0.,.3,.8]:
            full=solve(kappa=k,fuel=fuel,fee=fee,sigma_xi=sx)
            row=dict(kappa=k,sigma_xi=sx,fuel_loss=fuel,fee_per_leg=fee,one_factor=base,two_factor=full,difference=full-base)
            rows.append(row);print(json.dumps(row),flush=True)

# Fractional-volume reachability under the same start-of-day ratchet convention.
f=np.array([0.,.5,.8,1.]);w=np.array([.3,.7,1.,1.])
capacity=600000.;max_daily=10000.
v=0.
for _ in range(92):
    def residual(y):return y-max_daily*np.interp(y/capacity,f,w)-v
    v=capacity if residual(capacity)<=0 else brentq(residual,v,capacity)
rec=dict(check='fractional_volume_october_capacity',withdrawal_days=92,max_opening_fraction=v/capacity,max_opening_mwh=v)
rows.append(rec);print(json.dumps(rec),flush=True)
(ROOT/'evidence'/'two_factor_oracle.json').write_text(json.dumps(rows,indent=2))

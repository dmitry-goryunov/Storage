# Reproducing the independent investigation

Extract this archive into a new directory. The original project code and workbook are not included. The review used the files in the Storage project on 10 September 2026; `evidence/source_sha256.json` identifies the exact input bytes, including original line endings.

Use a Python environment with the project's dependencies, including NumPy, pandas, SciPy, Numba, pytest, openpyxl, matplotlib and Streamlit. The complete suite used Python 3.12.14, NumPy 2.5.3, pandas 3.0.5, SciPy 1.18.1 and Numba 0.67.0. Notebook gates also need the dependencies declared by the project. This archive does not install packages or alter your project.

From the extracted directory run:

```text
python run_review.py --project "H:\My Drive\Github\dmitry-goryunov\Storage"
```

Replace the example path with the actual project directory. The runner verifies the source hashes, copies only the listed project inputs into `source/`, and runs the existing suite and independent scripts against that isolated copy. It does not write to the original project. Hash differences require either the reviewed snapshot or the explicit `--allow-different-snapshot` option. Results from a different snapshot are a new investigation and must not be represented as reproduction of this report's numbers.

The output logs in this archive preserve the original investigation. Running the scripts again overwrites those logs and evidence outputs locally, so retain the downloaded archive if you want to keep the originals.

## Files

| Script | Purpose |
|---|---|
| `empirical_check.py` | Workbook diagnostics, raw and roll-excluded correlations, log-ratio volatilities, exploratory covariance fits and PCA summaries |
| `independent_checks.py` | Initial inventory, bound rounding, fuel and cash-fee accounting, ratchet refinement, reference values and Monte Carlo accounting |
| `followup_checks.py` | Grid-dependent floor feasibility, optimiser-generated stochastic floor breaches and analytic ratio volatilities |
| `two_factor_oracle.py` | Independent small one-/two-factor DP counterexample and fractional-volume withdrawal reachability |
| `reference_and_hedges.py` | Current notebook configurations and monthly hedge perturbations |
| `run_review.py` | Input verification, isolated copying and ordered execution |

`evidence/` contains JSON and CSV numerical results. The covariance-fit parameters are diagnostic only; they are not a market calibration. The small two-factor oracle is an independently written design counterexample and does not implement a production Schwartz–Smith lattice. Its common level factor is independent of the short factor, which suffices to test the design's universal value and sign claims. The broader continuous-time reduction in the report is an analytic derivation.

All calculations use the original public `storage_model` interface or a directly configured `Storage` object. The production modules are not patched. The synthetic checker-only distribution is labelled separately from the actual stochastic optimiser example.

The original suite output is in `pytest.log`. Other original logs use descriptive names (`empirical.log`, `independent.log`, `followup.log`, `two_factor.log`, `hedges.log`); the batch runner writes new logs using each script's full basename.

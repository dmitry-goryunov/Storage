#!/usr/bin/env python3
"""Targeted implementation acceptance checks, not production repairs.

Run against a Storage checkout with its locked dependencies. See README.md.
No project input files are changed. Temporary synthetic workbooks and caches
exercise the loader. FAIL means an acceptance requirement is not yet met;
ERROR means the check needs investigation, including possible API adaptation.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    root = args.source.resolve()
    sys.path.insert(0, str(root))
    import numpy as np
    import pandas as pd
    import storage_model as sm
    import benchmarks as b
    import two_factor_probe as p

    rows = []

    def check(check_id, requirement, function):
        try:
            passed, detail = function()
            status = "PASS" if passed else "FAIL"
        except Exception as exc:
            status, detail = "ERROR", {"exception": type(exc).__name__, "message": str(exc)}
        rows.append(dict(id=check_id, requirement=requirement, status=status, detail=detail))
        print(f"{status:5} {check_id}: {requirement}", flush=True)

    def close(a, c):
        return bool(np.isfinite(a) and abs(a-c) <= 1e-7 + 1e-10*abs(c))

    def physical(n, days_in=30, days_out=60, **changes):
        params = dict(product_type="storage", n_states=n, capacity_mwh=600_000.,
                      inj_days=days_in, wdr_days=days_out,
                      initial_storage_mwh=0., terminal_storage_mwh=0.)
        params.update(changes)
        return params

    def conversion(params, must_accept):
        try:
            out = sm.params_for_run_valuation(params)
        except ValueError as exc:
            # Intended contract refusal is acceptable only for a case known
            # independently to be incompatible. Other exceptions become ERROR.
            return not must_accept, {"outcome": "rejected", "message": str(exc)}
        for physical_field, clip_field in (("initial_storage_mwh", "initial_inv_clips"),
                                          ("terminal_storage_mwh", "terminal_inv_clips")):
            if params.get(clip_field) is not None:
                requested_step = params["capacity_mwh"]/params["n_states"]
                if not close(params[physical_field], params[clip_field]*requested_step):
                    return False, {"outcome": "conflicting inputs accepted",
                                   "physical_field": physical_field,
                                   "physical_quantity": params[physical_field],
                                   "clip_field": clip_field,
                                   "clip_quantity_mwh": params[clip_field]*requested_step}
        step = float(out["v_step"])
        actual = dict(capacity_mwh=step*int(out["n_states"]),
                      injection_mwh_day=step*float(out["inj_rate"]),
                      withdrawal_mwh_day=step*float(out["wdr_rate"]),
                      opening_mwh=step*float(out["initial_inv_clips"]),
                      terminal_mwh=step*float(out["terminal_inv_clips"]))
        expected = dict(capacity_mwh=params["capacity_mwh"],
                        injection_mwh_day=params["capacity_mwh"]/params["inj_days"],
                        withdrawal_mwh_day=params["capacity_mwh"]/params["wdr_days"],
                        opening_mwh=params["initial_storage_mwh"],
                        terminal_mwh=params["terminal_storage_mwh"])
        return all(close(actual[k], expected[k]) for k in expected), dict(
            outcome="accepted", requested=expected, effective=actual)

    for name, n, di, dw in [
        ("30_60_n60", 60, 30, 60), ("30_90_n90", 90, 30, 90),
        ("30_65_n390", 390, 30, 65), ("30_65_n780", 780, 30, 65),
        ("30_365_n2190", 2190, 30, 365),
    ]:
        check("R-"+name, "Compatible conversion preserves physical rates and volume",
              lambda n=n, di=di, dw=dw: conversion(physical(n, di, dw), True))
    for name, n, di, dw in [
        ("30_90_n30", 30, 30, 90), ("30_65_n60", 60, 30, 65),
        ("30_60_n45", 45, 30, 60), ("30_65_n90", 90, 30, 65),
        ("30_365_n30", 30, 30, 365),
    ]:
        check("R-"+name, "Incompatible conversion preserves the request or refuses it",
              lambda n=n, di=di, dw=dw: conversion(physical(n, di, dw), False))
    for name, changes, accept in [
        ("opening_exact", {"initial_storage_mwh": 20_000.}, True),
        ("terminal_exact", {"terminal_storage_mwh": 30_000.}, True),
        ("opening_half_clip", {"initial_storage_mwh": 5_000.}, False),
        ("terminal_half_clip", {"terminal_storage_mwh": 5_000.}, False),
        ("opening_conflict", {"initial_storage_mwh": 20_000., "initial_inv_clips": 1}, False),
        ("terminal_conflict", {"terminal_storage_mwh": 30_000., "terminal_inv_clips": 2}, False),
    ]:
        check("V-"+name, "Opening and terminal MWh are preserved or conflicting inputs refused",
              lambda changes=changes, accept=accept: conversion(physical(60, **changes), accept))

    def grid_request(params):
        try:
            step, n, cpd = sm.resolve_grid(params, "inj_days")
        except ValueError as exc:
            return True, {"outcome": "rejected", "message": str(exc)}
        good = close(step*n, params["capacity_mwh"])
        if params.get("n_states") is not None:
            good = good and n == params["n_states"]
        return good, dict(outcome="accepted", requested=params, effective_capacity=step*n,
                          effective_n_states=n, effective_step=step, clips_per_day=cpd)

    check("V-capacity_off_grid", "Explicit grid must not silently round capacity",
          lambda: grid_request(dict(capacity_mwh=100., v_step=30., clips_per_day=1)))
    check("V-conflicting_grid", "Conflicting explicit grid inputs must not be ignored",
          lambda: grid_request(dict(capacity_mwh=600_000., v_step=10_000., n_states=90,
                                    clips_per_day=2)))

    def daily_ratchet():
        model = SimpleNamespace(n_op=5, v_step=1., i_curve=np.array([1, 2]),
                                w_curve=np.array([1, 2]), i_ratch=np.full(5, .5),
                                w_ratch=np.full(5, .5))
        actual = sm.worst_ratchet_rate_loss(model)
        # At interior inventory and a base rate of one clip, .5 clips rounds
        # down to zero. The two-clip day happens to be exactly representable.
        return close(actual["injection"], 1.) and close(actual["withdrawal"], 1.), dict(
            expected_loss=1., reported=actual, daily_base_clips=[1, 2], multiplier=.5)

    check("R-daily_ratchet", "Rate diagnostic covers smaller active daily rates", daily_ratchet)

    def cache_case(same_path):
        original_cache = b._PARQUET_CACHE
        try:
            with tempfile.TemporaryDirectory(prefix="storage-acceptance-") as td:
                folder = Path(td)
                first, other = folder/"first.xlsx", folder/"other.xlsx"
                cache = folder/"quotes.parquet"
                b._PARQUET_CACHE = str(cache)
                def write(path, value):
                    pd.DataFrame({"quote_date": [pd.Timestamp("2026-01-05")],
                                  "TTFc1": [value]}).to_excel(path, index=False)
                write(first, 10.)
                first_stamp = first.stat().st_mtime
                initial = b.load_quote_matrix(first)
                if len(initial) != 1 or not close(float(initial["TTFc1"].iloc[0]), 10.):
                    raise AssertionError("Synthetic source did not initialise correctly")
                target = first if same_path else other
                write(target, 999.)
                stamp = first_stamp if same_path else first_stamp - 60
                os.utime(target, (stamp, stamp))
                actual = b.load_quote_matrix(target)
                value = float(actual["TTFc1"].iloc[0])
                return len(actual) == 1 and close(value, 999.), dict(
                    requested_rows=1, requested_c1=999., actual_rows=len(actual), actual_c1=value,
                    scenario="same path, changed bytes, restored mtime" if same_path
                    else "different workbook older than the cache")
        finally:
            b._PARQUET_CACHE = original_cache

    check("D-different_workbook", "An explicit workbook cannot read another source's cache",
          lambda: cache_case(False))
    check("D-same_path_new_bytes", "Content changes invalidate cache despite restored mtime",
          lambda: cache_case(True))

    def gate(grids, values, should_pass, refused=None):
        table = pd.DataFrame(dict(n_states=grids, total_eur=values, intrinsic_eur=values))
        if refused is not None:
            table["refused"] = refused
        try:
            accepted, steps = b.convergence_verdict(table)
        except ValueError as exc:
            return not should_pass, {"outcome": "rejected", "message": str(exc)}
        return bool(accepted) == should_pass, dict(
            expected_acceptance=should_pass, actual_acceptance=bool(accepted),
            grids=grids, values=values, refused=refused)

    for name, grids, values, expected, refused in [
        ("nan", [240,480,960], [math.nan]*3, False, None),
        ("infinity", [240,480,960], [math.inf]*3, False, None),
        ("duplicate", [240]*3, [1e6]*3, False, None),
        ("descending", [960,480,240], [1e6]*3, False, None),
        ("not_doublings", [240,500,960], [1e6]*3, False, None),
        ("refused_gap", [240,480,960,1920], [1e6,math.nan,1e6,1e6], False,
         [None,"unrepresentable grid",None,None]),
        ("material_small", [240,480,960], [10000.,9500.,9000.], False, None),
        ("stable_control", [240,480,960], [1e6,1002000.,1003000.], True, None),
        ("moving_control", [240,480,960], [1e6,1100000.,1200000.], False, None),
    ]:
        check("C-"+name, "Convergence verdict respects valid refinements and material moves",
              lambda grids=grids, values=values, expected=expected, refused=refused:
              gate(grids, values, expected, refused))

    def variance(sigma, kappa=4.):
        nodes, trans = p._ou_lattice(kappa, sigma)
        q = np.zeros(len(nodes)); q[len(nodes)//2] = 1.
        for _ in range(p.N_T-1):
            q = q @ trans
        return float(q @ nodes**2 - (q @ nodes)**2)

    def anchor():
        kappa, xi = 4., .1
        horizon = (p.N_T-1)*p.DT
        base = variance(p.SIG_CHI, kappa)
        chi = p.matched_sig_chi(xi, "terminal", kappa=kappa)
        nodes, trans = p._walk_lattice(xi)
        q = np.zeros(len(nodes)); q[len(nodes)//2] = 1.
        for _ in range(p.N_T-1): q = q @ trans
        long_variance = float(q @ nodes**2 - (q @ nodes)**2)
        actual = variance(chi, kappa) + long_variance
        return abs(actual-base) <= 1e-10 + 1e-8*base, dict(
            last_decision_years=horizon, base_variance=base, comparison_variance=actual,
            sigma_chi=chi, relative_mismatch=actual/base-1)

    check("P-terminal_anchor", "Terminal matching uses actual transition laws and decision horizon", anchor)

    # Independent formula examples. These are evidence for the guide, not
    # production acceptance passes and not market calibrations.
    rho, xi, sigma0 = -.9, .3, .6
    chi = -rho*xi + math.sqrt(sigma0**2-(1-rho**2)*xi**2)
    point = .5*(math.exp(-.5)-math.exp(-1.))
    averaged = point*math.expm1(1/12)/(1/12)
    base_var = variance(.6)
    actual_horizon = (p.N_T-1)*p.DT
    discrete_chi = math.sqrt(.6**2-.1**2*actual_horizon/(base_var/.6**2))
    references = dict(
        exact_rate_grid_examples={"30/90": math.lcm(30,90), "30/65": math.lcm(30,65)},
        correlated_variance_example=dict(rho=rho, sigma_xi=xi, sigma_chi=chi,
            total_variance=chi**2+xi**2+2*rho*chi*xi),
        monthly_delivery_example=dict(point_month_end_vol=point, delivery_average_vol=averaged),
        current_discrete_terminal_match=dict(base_variance=base_var,
            horizon=actual_horizon, sigma_chi=discrete_chi))
    hashes = {name: hashlib.sha256((root/name).read_bytes()).hexdigest()
              for name in ["storage_model.py", "storage_kernels.py", "benchmarks.py", "two_factor_probe.py"]}
    revision = subprocess.run(["git","-C",str(root),"rev-parse","HEAD"],
                              capture_output=True, text=True)
    counts = dict(Counter(x["status"] for x in rows))

    def safe(value):
        if isinstance(value, float) and not math.isfinite(value):
            return str(value)
        if isinstance(value, dict): return {k:safe(v) for k,v in value.items()}
        if isinstance(value, list): return [safe(v) for v in value]
        return value

    output = dict(generated_utc=datetime.now(timezone.utc).isoformat(), source_path=str(root),
                  git_commit=revision.stdout.strip() if revision.returncode == 0 else None,
                  source_sha256=hashes, python=sys.version.split()[0], numpy=np.__version__,
                  pandas=pd.__version__, summary=counts, checks=rows, references=references,
                  scope="Targeted acceptance pack; no complete valuation suite or market calibration")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(safe(output), indent=2, allow_nan=False)+"\n", encoding="utf-8")
    print(json.dumps(counts), flush=True)
    return 2 if counts.get("ERROR",0) else 1 if counts.get("FAIL",0) else 0


if __name__ == "__main__":
    raise SystemExit(main())

# Storage implementation acceptance pack

11 September 2026. Companion to `IMPLEMENTATION-GUIDE-2026-09-11.md` in Storage/docs.

This pack makes selected unresolved review findings directly checkable. It does not implement the proposed production repairs and is not a replacement for the repository test suite.

## Contents

- `check_acceptance.py`: 31 targeted requirements using the existing Storage API.
- `baseline-results.json`: dated observed results against the reviewed source snapshot.
- `manifest.json`: SHA-256 hashes of the pack files, and the canonical source revision to which the snapshot was reconciled.
- `README.md`: scope, execution and result interpretation.

The baseline is canonical GitHub commit `b66d0a4b9a99b3772258007401bceefa24142f33` in `dmitry-goryunov/Storage`. The script ran against an extracted source snapshot, so `git_commit` in the JSON is null. The earlier evening review independently reconciled the inspected source files to that commit, allowing CRLF/LF normalisation. Exact local source-byte hashes are recorded in the JSON; text hashes may differ from a Linux checkout solely because of line endings.

## Run

Use Python 3.12 and the repository's `requirements-lock.txt` in an environment outside the synchronised project directory. The recorded run used Python 3.12.14, NumPy 2.5.3 and pandas 3.0.5, with the repository's locked SciPy/Numba dependencies available for imports. A parquet engine and Excel reader/writer are required by the synthetic cache checks; use the project's environment rather than installing arbitrary replacement versions.

Extract this archive to `docs/acceptance-pack` or any other local directory. From the repository root, with the intended Python environment active:

```bash
python docs/acceptance-pack/check_acceptance.py --source . --output docs/acceptance-pack/current-results.json
```

For an external extraction directory, use its path to the script and output instead. The `--source` argument must point to the directory containing `storage_model.py`, `benchmarks.py` and `two_factor_probe.py`.

No market workbook is needed for these checks. The loader tests create small temporary workbooks and redirect the current module's cache path into the same temporary directory, restoring the original setting afterwards. They do not write the repository workbook or its existing parquet cache. Python may create ordinary import caches in the source directory.

## Expected baseline

The baseline has **31 checks: 9 PASS, 22 FAIL, no ERROR**. Exit code 1 is expected before repairs. This is a deliberately targeted set of known gaps and passing controls, not a representative sample for estimating project reliability.

| Group | Checks | Baseline PASS | Baseline FAIL | Requirement |
|---|---:|---:|---:|---|
| Rates and daily ratchet diagnostic, R | 11 | 5 | 6 | Preserve requested rates; measure lower-rate days |
| Capacity and boundary inventory, V | 8 | 2 | 6 | Preserve physical volumes; reject contradictions |
| Data source and cache, D | 2 | 0 | 2 | Consume the requested bytes |
| Convergence verdict, C | 9 | 2 | 7 | Validate refinements and material changes |
| Probe terminal anchor, P | 1 | 0 | 1 | Match actual variance at the actual observation time |

- `PASS`: the case met its stated expected behaviour. A deliberate rejection of an incompatible input may be a pass.
- `FAIL`: the check completed and observed an unmet requirement.
- `ERROR`: an unexpected exception occurred. Investigate it; do not count it as a successful input refusal.

Process exits: 0 for all checks passing, 1 for any FAIL, 2 for any ERROR. Missing dependencies or import failures can also stop the process before a report; those are environment failures, not acceptance evidence.

Non-finite synthetic inputs appear as strings such as `nan` and `inf` in the output JSON, keeping it valid strict JSON. They are actual non-finite floats when passed into the production gate.

## Independence and limits

Physical expected rates come from the original capacity/days inputs, not the production conversion. The smaller-daily-rate example calculates the loss directly from a one-clip rate and a half multiplier. Probe variance is measured by forward propagation through the actual transition matrix rather than by reusing the anchor formula. Cache cases use distinctive synthetic values. Convergence cases include malformed input tables and valid passing/failing controls.

The reference section also records an integer-grid calculation, a correlated variance counterexample and a delivery-average calculation. These are independent mathematical illustrations. They are not additional acceptance passes and are not market calibrations.

The conversion checks allow exact preservation or a `ValueError` for known incompatible grids. The guide recommends a stricter default: an explicitly incompatible requested grid is rejected. Add that strict-mode assertion when implementing the new interface. Conflicting physical/clip fields must be rejected, not resolved by silently selecting one.

The convergence small-contract case specifies a material EUR 500 movement around a EUR 10,000 value. It is intentionally unacceptable under the guide's proposed engineering rule. That proposed rule still needs commercial calibration before use as a decision-grade tolerance.

These checks do not cover the full valuation recursion, all valid input domains, Streamlit cache integration, schema-version invalidation, a high-resolution convergence ladder, correlation in a new lattice, held-out calibration or the final architecture decision. The guide specifies those additional checks. The previously completed evening review supplies the independent small-contract schedule oracle and full-suite evidence.

## After implementation

Run the affected check group and add integration tests in the repository. The script currently runs all 31 short checks; it performs no expensive storage valuation ladder.

If APIs change, update only the adapter calls and preserve the expected mathematical/physical properties. For example:

1. If quote loading moves into `quote_data.py`, direct the synthetic cache tests at that loader and its explicit temporary cache location.
2. If the convergence verdict requires configuration identities, supply an identical valid identity to the controls and add a deliberately mismatched-identity refusal case.
3. If the probe receives explicit decision times, pass the actual final observation index into the anchor and probability propagation.
4. Do not suppress errors from missing or renamed functions as though they were valid refusals.

Write subsequent runs to `current-results.json` or a revision-specific filename. Preserve `baseline-results.json` as the dated record. Once the relevant properties pass, run the required repository suite in a real Git checkout and attach the exact commit and results to the code review.
